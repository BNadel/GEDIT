library(testthat)
library(dtangle)

test_check("dtangle")
